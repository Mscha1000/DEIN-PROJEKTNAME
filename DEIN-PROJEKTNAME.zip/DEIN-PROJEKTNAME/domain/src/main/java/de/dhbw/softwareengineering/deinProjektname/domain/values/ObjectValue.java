package de.dhbw.softwareengineering.deinProjektname.domain.values;

//In das Package werden die lauter Klassen für die ObjectValues angelegt
public class ObjectValue {

}
