package de.dhbw.softwareengineering.deinProjektname.domain.entities;

public class SpendingSumLimiterEntity {

    private double maxSpendingSum;

    public double getMaxSpendingSum() {return maxSpendingSum;}

    public void setMaxSpendingSum(double maxSpendingSum) {this.maxSpendingSum = maxSpendingSum;}
}
