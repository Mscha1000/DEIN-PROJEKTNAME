package de.dhbw.softwareengineering.deinProjektname.domain.repositories;

public interface BridgeRepository {
	void deleteById(Long id);
}
