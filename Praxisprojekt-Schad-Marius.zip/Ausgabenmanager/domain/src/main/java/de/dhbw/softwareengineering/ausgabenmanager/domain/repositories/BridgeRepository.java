package de.dhbw.softwareengineering.ausgabenmanager.domain.repositories;

public interface BridgeRepository {
	void deleteById(Long id);
}
