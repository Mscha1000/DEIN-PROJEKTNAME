package de.dhbw.softwareengineering.ausgabenmanager.domain.values;

public class ObjectValue {

}
